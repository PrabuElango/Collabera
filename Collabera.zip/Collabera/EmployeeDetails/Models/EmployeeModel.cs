﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace EmployeeDetails.Models
{
    public class EmployeeModel
    {        
        public string EmpName{ get; set; }
        public string EmpDob { get; set; }
        public string EmpSal { get; set; }

    }
}
