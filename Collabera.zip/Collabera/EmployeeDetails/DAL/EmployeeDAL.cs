﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;
using EmployeeDetails.Models;

namespace EmployeeDetails.DAL
{
    public class EmployeeDAL
    {       
        public static IEnumerable<EmployeeModel> GetEmployees()
        {
            List<EmployeeModel> lstEmployee = new List<EmployeeModel>();
            Connection.OpenConnection();
            SqlCommand cmd = new SqlCommand("spGetEmployee", Connection.con);
            cmd.CommandType = CommandType.StoredProcedure;                
            SqlDataReader rdr = cmd.ExecuteReader();
              while (rdr.Read())
                {
                EmployeeModel employee = new EmployeeModel();
                    
                    employee.EmpName = rdr["EmpName"].ToString();
                    employee.EmpDob = rdr["EmpDob"].ToString();
                    employee.EmpSal = rdr["EmpSal"].ToString();
                    lstEmployee.Add(employee);
                }
                Connection.con.Close();
            
            return lstEmployee;
        }

        public static void AddEmployee(EmployeeModel employee)
        {            
                SqlCommand cmd = new SqlCommand("spAddEmployee", Connection.con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@EmpName", employee.EmpName);
                cmd.Parameters.AddWithValue("@EmpDob", employee.EmpDob);
                cmd.Parameters.AddWithValue("@EmpSal", employee.EmpSal);                
                Connection.con.Open();
                cmd.ExecuteNonQuery();
                Connection.con.Close();            
        }
    }
}
