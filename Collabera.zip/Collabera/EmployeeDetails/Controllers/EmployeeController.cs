﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using EmployeeDetails.Models;
using EmployeeDetails.DAL;
namespace EmployeeDetails.Controllers
{
    
    public class EmployeeController : Controller
    {
        
        public ActionResult GetEmployee()
        {
            IEnumerable<EmployeeModel> employee = EmployeeDAL.GetEmployees();
            ViewBag.employee = employee;
            return View();
        }
         
        public ActionResult CreateEmployee(EmployeeModel employee)
        {
            try
            {
                if (!string.IsNullOrEmpty(employee.EmpDob)&& !string.IsNullOrEmpty(employee.EmpName) && !string.IsNullOrEmpty(employee.EmpSal))
                    {
                    EmployeeDAL.AddEmployee(employee);
                    return RedirectToAction(nameof(GetEmployee));
                }
                return RedirectToAction(nameof(GetEmployee));
            }
            catch (Exception ex)
            {
                return View(ex);
            }
        }
    }
}
