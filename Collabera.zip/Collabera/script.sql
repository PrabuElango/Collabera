USE [master]
GO
/****** Object:  Database [Employee]    Script Date: 04/17/2021 23:58:56 ******/
CREATE DATABASE [Employee]
GO
ALTER DATABASE [Employee] SET COMPATIBILITY_LEVEL = 100
GO
IF (1 = FULLTEXTSERVICEPROPERTY('IsFullTextInstalled'))
begin
EXEC [Employee].[dbo].[sp_fulltext_database] @action = 'enable'
end
GO
ALTER DATABASE [Employee] SET ANSI_NULL_DEFAULT OFF
GO
ALTER DATABASE [Employee] SET ANSI_NULLS OFF
GO
ALTER DATABASE [Employee] SET ANSI_PADDING OFF
GO
ALTER DATABASE [Employee] SET ANSI_WARNINGS OFF
GO
ALTER DATABASE [Employee] SET ARITHABORT OFF
GO
ALTER DATABASE [Employee] SET AUTO_CLOSE OFF
GO
ALTER DATABASE [Employee] SET AUTO_CREATE_STATISTICS ON
GO
ALTER DATABASE [Employee] SET AUTO_SHRINK OFF
GO
ALTER DATABASE [Employee] SET AUTO_UPDATE_STATISTICS ON
GO
ALTER DATABASE [Employee] SET CURSOR_CLOSE_ON_COMMIT OFF
GO
ALTER DATABASE [Employee] SET CURSOR_DEFAULT  GLOBAL
GO
ALTER DATABASE [Employee] SET CONCAT_NULL_YIELDS_NULL OFF
GO
ALTER DATABASE [Employee] SET NUMERIC_ROUNDABORT OFF
GO
ALTER DATABASE [Employee] SET QUOTED_IDENTIFIER OFF
GO
ALTER DATABASE [Employee] SET RECURSIVE_TRIGGERS OFF
GO
ALTER DATABASE [Employee] SET  DISABLE_BROKER
GO
ALTER DATABASE [Employee] SET AUTO_UPDATE_STATISTICS_ASYNC OFF
GO
ALTER DATABASE [Employee] SET DATE_CORRELATION_OPTIMIZATION OFF
GO
ALTER DATABASE [Employee] SET TRUSTWORTHY OFF
GO
ALTER DATABASE [Employee] SET ALLOW_SNAPSHOT_ISOLATION OFF
GO
ALTER DATABASE [Employee] SET PARAMETERIZATION SIMPLE
GO
ALTER DATABASE [Employee] SET READ_COMMITTED_SNAPSHOT OFF
GO
ALTER DATABASE [Employee] SET HONOR_BROKER_PRIORITY OFF
GO
ALTER DATABASE [Employee] SET  READ_WRITE
GO
ALTER DATABASE [Employee] SET RECOVERY FULL
GO
ALTER DATABASE [Employee] SET  MULTI_USER
GO
ALTER DATABASE [Employee] SET PAGE_VERIFY CHECKSUM
GO
ALTER DATABASE [Employee] SET DB_CHAINING OFF
GO
EXEC sys.sp_db_vardecimal_storage_format N'Employee', N'ON'
GO
USE [Employee]
GO
/****** Object:  Table [dbo].[EmpDetails]    Script Date: 04/17/2021 23:58:57 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[EmpDetails](
	[EmpCode] [int] IDENTITY(1,1) NOT NULL,
	[EmpName] [varchar](150) NULL,
	[EmpDob] [varchar](150) NULL,
	[EmpSal] [varchar](50) NULL,
PRIMARY KEY CLUSTERED 
(
	[EmpCode] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
SET IDENTITY_INSERT [dbo].[EmpDetails] ON
INSERT [dbo].[EmpDetails] ([EmpCode], [EmpName], [EmpDob], [EmpSal]) VALUES (1, N'Ganesh', N'02-05-1999', N'5000')
INSERT [dbo].[EmpDetails] ([EmpCode], [EmpName], [EmpDob], [EmpSal]) VALUES (2, N'Yuvaraj', N'06-06-2000', N'8000')
INSERT [dbo].[EmpDetails] ([EmpCode], [EmpName], [EmpDob], [EmpSal]) VALUES (3, N'Prabu', N'02-02-1989', N'5000')
INSERT [dbo].[EmpDetails] ([EmpCode], [EmpName], [EmpDob], [EmpSal]) VALUES (4, N'Tuhi', N'03-04-2018', N'100000')
INSERT [dbo].[EmpDetails] ([EmpCode], [EmpName], [EmpDob], [EmpSal]) VALUES (5, N'Santhosh', N'02-03-2078', N'40004')
INSERT [dbo].[EmpDetails] ([EmpCode], [EmpName], [EmpDob], [EmpSal]) VALUES (6, N'Sabari', N'03-05-2019', N'20000')
SET IDENTITY_INSERT [dbo].[EmpDetails] OFF
/****** Object:  StoredProcedure [dbo].[spGetEmployee]    Script Date: 04/17/2021 23:58:58 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
create procedure [dbo].[spGetEmployee]
As
select * from EmpDetails
Go;
GO
/****** Object:  StoredProcedure [dbo].[spAddEmployee]    Script Date: 04/17/2021 23:58:58 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
create procedure [dbo].[spAddEmployee](@EmpName varchar(150),@EmpDob varchar(150),@EmpSal varchar(150))
As
Begin
insert into EmpDetails (EmpName,EmpDob,EmpSal) values (@EmpName,@EmpDob,@EmpSal)
End
GO
